package com.diksha.pdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfGeneratorItextApplicationTests {

	@Test
	void contextLoads() {
	}

}
