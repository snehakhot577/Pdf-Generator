package com.diksha.pdf;

public class TicketsDto {
	
	private String ticketName;

	public TicketsDto() {
		super();
		
	}

	public String getTicketName() {
		return ticketName;
	}

	public void setTicketName(String ticketName) {
		this.ticketName = ticketName;
	}
	
	

}
