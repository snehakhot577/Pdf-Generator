package com.diksha.pdf;

public class AmountDto {
	
	
	private String amount;

	public AmountDto() {
		super();
		
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	
	

}
